﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using WebApplication55.Models;

namespace WebApplication55.Data
{
    public class EmployeeDbContext:DbContext
    {
        public EmployeeDbContext(DbContextOptions<EmployeeDbContext> options)
            :base (options)
        {

        }
        public DbSet<Employee> Employee { get; set; }
    }
}
