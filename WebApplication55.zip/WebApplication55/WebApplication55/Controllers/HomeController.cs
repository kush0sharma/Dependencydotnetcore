﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication55.Models;
using WebApplication55.Services.IServices;

namespace WebApplication55.Controllers
{
    public class HomeController : Controller
    {
        public readonly IEmployeeService _IEmployeeService;
        public HomeController(IEmployeeService iEmployeeService)
        {
            _IEmployeeService = iEmployeeService;
        }
        public IActionResult Index()
        {

            return View(_IEmployeeService.GetAllEmployee());
        }

       
    }
}
