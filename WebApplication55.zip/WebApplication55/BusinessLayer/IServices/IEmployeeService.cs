﻿using System;
using System.Collections.Generic;
using System.Text;
using WebApplication55.Models;

namespace WebApplication55.Services.IServices
{
    public interface IEmployeeService
    {
        List<Employee> GetAllEmployee();
    }
}
