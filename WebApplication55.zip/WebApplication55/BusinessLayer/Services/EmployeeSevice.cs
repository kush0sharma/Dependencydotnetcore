﻿using System;
using System.Collections.Generic;
using System.Text;
using WebApplication55.Data;
using WebApplication55.Models;
using WebApplication55.Services.IServices;
using System.Linq;
namespace WebApplication55.Services.Services
{
    public class EmployeeSevice : IEmployeeService
    {
        EmployeeDbContext _DbContext;
        public EmployeeSevice(EmployeeDbContext DbContext)
        {
            _DbContext = DbContext;
        }

        public List<Employee> GetAllEmployee()
        {
            List<Employee> emp = _DbContext.Employee.ToList();
            return emp;
        }
        
    }
}
